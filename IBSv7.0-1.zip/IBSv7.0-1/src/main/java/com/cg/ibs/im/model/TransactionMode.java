package com.cg.ibs.im.model;
public enum TransactionMode {
	ONLINE, CASH;
}
