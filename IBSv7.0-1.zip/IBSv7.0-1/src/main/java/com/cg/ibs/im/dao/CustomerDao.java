package com.cg.ibs.im.dao;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.exception.IBSCustomException;

public interface CustomerDao {
	
	
	boolean saveCustomer(Customer customer) throws IBSCustomException;
	
	Customer getCustomerDetails(String uci) throws IBSCustomException;
	
	Set<BigInteger> getAllCustomers() throws IBSCustomException;

	Customer getCustomerByApplicantId(Long applicantId) throws IBSCustomException;

	boolean checkCustomerByUsernameExists(String username) throws IBSCustomException;

	boolean checkCustomerExists(BigInteger uci) throws IBSCustomException;

	boolean updateCustomer(Customer customer) throws IBSCustomException;
}
