package com.cg.ibs.im.dao;

import com.cg.ibs.im.exception.IBSCustomException;

public interface BankerDao {

//	BankAdmins addNewBanker();
	
	boolean checkBankerLogin(String adminId, String password) throws IBSCustomException;

}
