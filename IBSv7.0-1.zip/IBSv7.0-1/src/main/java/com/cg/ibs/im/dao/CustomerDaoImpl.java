package com.cg.ibs.im.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;


@Repository("customerDao")
public class CustomerDaoImpl implements CustomerDao {
	@PersistenceContext
	private EntityManager entityManager;
	private Customer customer;

	

	@Override
	public boolean saveCustomer(Customer customer) throws IBSCustomException {
		if (customer != null) {
			entityManager.persist(customer);
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return false;
	}

	@Override
	public Customer getCustomerDetails(String userId) throws IBSCustomException {
		customer = new Customer();
		TypedQuery<Customer> query = entityManager.createNamedQuery("checkCustomerByUserId", Customer.class);
		query.setParameter("userId", userId);
		try {
			customer = (Customer) query.getSingleResult();
		} catch (NoResultException exception) {
			customer = null;
		}
		return customer;
	}
	
	@Override
	public Set<BigInteger> getAllCustomers() throws IBSCustomException {
		TypedQuery<BigInteger> query = entityManager.createNamedQuery("getAllCustomers", BigInteger.class);
		List<BigInteger> customerSet = query.getResultList();
		Set<BigInteger> customers = new HashSet<BigInteger>();
		for (BigInteger uci : customerSet) {
			customers.add(uci);
		}
		return customers;
	}

	@Override
	public Customer getCustomerByApplicantId(Long applicantId) throws IBSCustomException {

		TypedQuery<Customer> query = entityManager.createNamedQuery("getCustomerByApplicantId", Customer.class);
		query.setParameter("applicantId", applicantId);
		customer = query.getSingleResult();
		if (customer == null)
			throw new IBSCustomException(IBSException.SQLError);
		return customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) throws IBSCustomException {
		boolean result = false;
//		String userId = customer.getUserId();
//		Integer login = (Integer) customer.getLogin();
//		String password = customer.getPassword();
//		TypedQuery<CustomerBean> query = entityManager.createNamedQuery("updateCustomer", CustomerBean.class);
//		query.setParameter("password", password);
//		query.setParameter("login", login);
//		query.setParameter("userId", userId);
//		
//		try {
//			customer = (CustomerBean) query.getSingleResult();
//		} catch (NoResultException exception) {
//			customer = null;
//		}
//		if (customer != null) {
//			result = true;
//		}
		Customer cust = entityManager.find(Customer.class, customer.getUci());
		if (cust != null) {
			entityManager.merge(cust);
			result = true;
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

	@Override
	public boolean checkCustomerByUsernameExists(String username) throws IBSCustomException {
		boolean result = false;
		TypedQuery<Customer> query = entityManager.createNamedQuery("checkCustomerByUserId", Customer.class);
		query.setParameter("userId", username);
		try {
			customer = (Customer) query.getSingleResult();
		} catch (NoResultException exception) {
			customer = null;
		}
		if (customer != null) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean checkCustomerExists(BigInteger uci) throws IBSCustomException {
		boolean result = false;
		customer = entityManager.find(Customer.class, uci);
		if (customer != null) {
			result = true;
		}
		return result;
	}

}
