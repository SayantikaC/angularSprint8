package com.cg.ibs.im.exception;

public interface IBSException {
	public static String customerNotPresent = "Customer not present";
	public static String applicantNotFound = "Applicant Not Found";	
	public static String invalidApplicantId = "Invalid Applicant Id";
	public static String incorrectUsernamePassword = "INCORRECT USERNAME/PASSWORD";
	
	public static String SQLError="Internal Error!! Try Again";
	public static String SQLErrorInput="Internal Error!! Try Again";
	public static String fileNotFound="Internal Error!! Try Again";
	public static String ioexception="Documents not uploaded";
}
