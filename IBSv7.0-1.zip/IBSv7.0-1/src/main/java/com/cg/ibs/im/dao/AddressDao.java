package com.cg.ibs.im.dao;

import com.cg.ibs.im.model.Address;
import com.cg.ibs.im.exception.IBSCustomException;

public interface AddressDao {

	Long saveAddress(Address address) throws IBSCustomException;

	Address getAddress(long applicantId) throws IBSCustomException;

}
